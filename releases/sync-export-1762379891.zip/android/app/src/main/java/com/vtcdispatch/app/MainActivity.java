package com.vtcdispatch.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
